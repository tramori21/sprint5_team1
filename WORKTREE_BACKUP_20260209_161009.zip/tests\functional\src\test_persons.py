﻿import aiohttp
import pytest

from settings import API_HOST


TIMEOUT = aiohttp.ClientTimeout(total=5)


@pytest.mark.asyncio
async def test_person_get_by_id():
    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/persons/person-1") as resp:
            assert resp.status == 200
            data = await resp.json()
            assert data["id"] == "person-1"
            assert data["full_name"] == "Keanu Reeves"


@pytest.mark.asyncio
async def test_person_films_contains_matrix():
    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/persons/person-1/film?page[number]=1&page[size]=10") as resp:
            assert resp.status == 200
            data = await resp.json()
            assert any(x["id"] == "film-1" for x in data)
