﻿import json
from pathlib import Path

from elasticsearch import AsyncElasticsearch


BASE_DIR = Path(__file__).resolve().parents[1]  # tests/functional
TESTDATA_DIR = BASE_DIR / "testdata"


def _read_json(name: str) -> list[dict]:
    return json.loads((TESTDATA_DIR / name).read_text(encoding="utf-8-sig"))


async def load_data():
    es = AsyncElasticsearch(hosts=["http://elasticsearch:9200"])

    # пересоздаём индексы, чтобы тесты были детерминированными
    for idx in ("movies", "genres", "persons"):
        await es.indices.delete(index=idx, ignore_unavailable=True)

    await es.indices.create(
        index="movies",
        mappings={
            "properties": {
                "id": {"type": "keyword"},
                "title": {"type": "text", "fields": {"keyword": {"type": "keyword"}}},
                "imdb_rating": {"type": "float"},
                "persons": {"type": "keyword"},
            }
        },
    )
    await es.indices.create(
        index="genres",
        mappings={
            "properties": {
                "id": {"type": "keyword"},
                "name": {"type": "text", "fields": {"keyword": {"type": "keyword"}}},
            }
        },
    )
    await es.indices.create(
        index="persons",
        mappings={
            "properties": {
                "id": {"type": "keyword"},
                "full_name": {"type": "text", "fields": {"keyword": {"type": "keyword"}}},
            }
        },
    )

    for doc in _read_json("films.json"):
        await es.index(index="movies", id=doc["id"], document=doc, refresh="wait_for")

    for doc in _read_json("genres.json"):
        await es.index(index="genres", id=doc["id"], document=doc, refresh="wait_for")

    for doc in _read_json("persons.json"):
        await es.index(index="persons", id=doc["id"], document=doc, refresh="wait_for")

    await es.close()

