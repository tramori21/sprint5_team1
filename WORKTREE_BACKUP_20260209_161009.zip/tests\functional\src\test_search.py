﻿import json

import aiohttp
import pytest
import redis.asyncio as redis
from elasticsearch import AsyncElasticsearch

from settings import API_HOST

TIMEOUT = aiohttp.ClientTimeout(total=5)


@pytest.mark.asyncio
async def test_search_validation_missing_query():
    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/search/") as resp:
            assert resp.status == 422


@pytest.mark.asyncio
async def test_search_validation_empty_query():
    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/search/?query=") as resp:
            assert resp.status == 422


@pytest.mark.asyncio
async def test_search_validation_page_size_zero():
    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/search/?query=matrix&page[number]=1&page[size]=0") as resp:
            assert resp.status == 422


@pytest.mark.asyncio
async def test_search_phrase_and_limit_n():
    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/search/?query=matrix&page[number]=1&page[size]=1") as resp:
            assert resp.status == 200
            data = await resp.json()
            assert isinstance(data, list)
            assert len(data) == 1
            assert data[0]["id"] == "film-1"


@pytest.mark.asyncio
async def test_search_cache_in_redis_restore_es_after():
    r = redis.Redis(host="redis", port=6379)
    await r.flushall()

    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/search/?query=matrix&page[number]=1&page[size]=10") as resp:
            assert resp.status == 200
            data = await resp.json()
            assert any(x["id"] == "film-1" for x in data)

    cached = await r.get("search:matrix:1:10")
    assert cached is not None
    cached_list = json.loads(cached)
    assert any(x["id"] == "film-1" for x in cached_list)

    # проверка “работает из кеша”: временно удаляем film-1 из ES и повторяем запрос
    es = AsyncElasticsearch(hosts=["http://elasticsearch:9200"])
    src = await es.get(index="movies", id="film-1")
    film_doc = src["_source"]

    await es.delete(index="movies", id="film-1", refresh=True)

    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/search/?query=matrix&page[number]=1&page[size]=10") as resp:
            assert resp.status == 200
            from_cache = await resp.json()
            assert any(x["id"] == "film-1" for x in from_cache)

    # восстановить документ обратно
    await es.index(index="movies", id="film-1", document=film_doc, refresh="wait_for")
    await es.close()
    await r.aclose()
