﻿import json

import aiohttp
import pytest
import redis.asyncio as redis
from elasticsearch import AsyncElasticsearch

from settings import API_HOST

TIMEOUT = aiohttp.ClientTimeout(total=5)


@pytest.mark.asyncio
async def test_films_list_limit_n():
    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/films/?page[number]=1&page[size]=1") as resp:
            assert resp.status == 200
            data = await resp.json()
            assert isinstance(data, list)
            assert len(data) == 1


@pytest.mark.asyncio
async def test_films_list_validation_page_size_zero():
    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/films/?page[number]=1&page[size]=0") as resp:
            assert resp.status == 422


@pytest.mark.asyncio
async def test_film_get_by_id():
    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/films/film-1") as resp:
            assert resp.status == 200
            data = await resp.json()
            assert data["id"] == "film-1"
            assert data["title"] == "The Matrix"


@pytest.mark.asyncio
async def test_film_not_found():
    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/films/unknown") as resp:
            assert resp.status == 404


@pytest.mark.asyncio
async def test_film_cache_in_redis_restore_es_after():
    r = redis.Redis(host="redis", port=6379)
    await r.flushall()

    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/films/film-1") as resp:
            assert resp.status == 200
            original = await resp.json()

    cached = await r.get("film:film-1")
    assert cached is not None
    assert json.loads(cached)["id"] == "film-1"

    es = AsyncElasticsearch(hosts=["http://elasticsearch:9200"])
    await es.delete(index="movies", id="film-1", refresh=True)

    async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
        async with session.get(f"{API_HOST}/api/v1/films/film-1") as resp:
            assert resp.status == 200
            from_cache = await resp.json()

    assert from_cache == original

    # ВАЖНО: восстановить документ обратно, чтобы другие тесты не падали
    await es.index(index="movies", id=original["id"], document=original, refresh="wait_for")
    await es.close()
    await r.aclose()
